##Moved to another repo: [https://github.com/InfinitumThemes/slimpost](https://github.com/InfinitumThemes/slimpost)

