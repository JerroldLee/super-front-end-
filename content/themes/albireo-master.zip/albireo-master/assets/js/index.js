/**
 * Main JS file for Casper behaviours
 */

(function ($) {
    "use strict";

    $(document).ready(function(){

        /* Empty */

    });

}(jQuery));